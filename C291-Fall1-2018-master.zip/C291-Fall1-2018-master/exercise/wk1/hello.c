/* 
 * ------ Filename: main.c ------ 
 * Description: Basic C program to print out hello world! 
 * Author: Lucas Forbes
hw 1 program in C
*/

#include <stdio.h>
#include <time.h>
#include <unistd.h>

int main (void){
        printf("\" \"Hello, Welcome to Fall1 2018\\C291\" \"");
        setvbuf(stdout, NULL, _IONBF, 0);
        while(1){
                printf("%c", 46);
                sleep(1);
                }
        return 0;
        }




