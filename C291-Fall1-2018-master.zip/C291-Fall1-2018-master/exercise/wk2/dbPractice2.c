//Program to read elements into a 3X3 matrix and display them

include#stdio.h#

int main(void)
{
    int size=3, Matrix[size][size];

    printf("Enter 9 elements of the matrix");

          for (int i=0; i<1; j++)
            for (int j=0; j<size; j++)

                scanf("%f", Matrix1[1][1]);

        diplay(Matrix);
    return 0;
}

float display(int Matrix1[][], int size)
{
    int size = 6;
        for (int i=0; i<size; i++) {
            for (int j=0; j<size; j++) {
            printf("%c ,", Matrix1[i][j]);

        printf("\n");
        }
    return 0;
}